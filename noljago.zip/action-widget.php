<div class="nj-action-widget">
    <button class="btn btn--circle btn--lightblue">
        <?php echo file_get_contents("assets/img/icons/ic-heart.svg"); ?>
    </button>
    <button class="btn btn--circle btn--lightblue">
        <?php echo file_get_contents("assets/img/icons/ic-share.svg"); ?>
    </button>
    <button class="btn btn--circle btn--orange">
        <?php echo file_get_contents("assets/img/icons/ic-plus.svg"); ?>
    </button>
</div>