<?php
    include("header.php");
?>

<section class="display__grid">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-4">
                <div class="display__container">
                    <h1>Button Size</h1>
                    <div class="display__body">
                        <a class="btn btn--primary btn--lg" href="">Button</a>
                        <a class="btn btn--primary btn--md" href="">Button</a>
                        <a class="btn btn--primary btn--sm" href="">Button</a>
                        <a class="btn btn--primary btn--xs" href="">Button</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                 <div class="display__container">
                    <h1>Button Size</h1>
                    <div class="display__body">
                        <a class="btn btn--primary btn--lg" href="">Button</a>
                        <a class="btn btn--primary btn--md" href="">Button</a>
                        <a class="btn btn--primary btn--sm" href="">Button</a>
                        <a class="btn btn--primary btn--xs" href="">Button</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                
            </div>
        </div>
    </div>
</section>


<?php
    include("footer.php");
?>