 <!-- Sidebar Navigation (Mobile Devices) -->
 <nav class="" id="nj-lateral-nav">
     <ul class="nj-navigation">
         <li><a class="nj-navigation__link page--active" href="index.php">Accomodations</a></li>
         <li><a class="nj-navigation__link" href="#">Experiences</a></li>
         <li><a class="nj-navigation__link" href="#">Experiences</a></li>
         <li><a class="nj-navigation__link" href="#">Experiences</a></li>
         <li><a class="nj-navigation__link" href="#">Experiences</a></li>
         <li><a class="nj-navigation__link" href="#">Experiences</a></li>
         <li><a class="nj-navigation__link" href="#">Experiences</a></li>
     </ul>
 </nav>